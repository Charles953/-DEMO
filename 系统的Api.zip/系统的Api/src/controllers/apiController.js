'use strict'

let successState = 0 ;//表示成功
let fialState = 1; //表示失败



//1.0 获取首页的数据(要实现分页)
exports.getlist = (req,res)=>{

	let resObj = {status:successState,message:''};

   //目标： 分页的sql语句: select vid,vtitle,vsummary,vimg from videinfo limit 跳过的条数,获取的条数(10)
   let pageIndex = req.query.PageIndex || 1;
   let pageSize = 10;
   let skipRow = (pageIndex - 1) * pageSize;

   let sql = 'select vid,vtitle,vsummary,vimg from videinfo  limit '+skipRow +','+pageSize;
   req.db.driver.execQuery(sql,(err,datas)=>{

   	if(err)
   	{
   		resObj.status = fialState;
   		resObj.message= err.message;
   		res.end(JSON.stringify(resObj));
   		return;
   	}

   	//5.0 获取数据成功
   	resObj.message = datas;
   	res.end(JSON.stringify(resObj));
   });

}


//2.0 获取指定vid的视频详情和视频播放id
exports.getvideo = (req,res)=>{

	let resObj = {status:successState,message:''};
	
	let vid = req.query.vid;

	let sql ='select vvideid,vremark from videinfo where vid='+vid;
	req.db.driver.execQuery(sql,(err,data)=>{
   	if(err)
   	{
   		resObj.status = fialState;
   		resObj.message= err.message;
   		res.end(JSON.stringify(resObj));
   		return;
   	}
   
   	resObj.message = data;
   	res.end(JSON.stringify(resObj));

	});
}