'use strict'

const express = require('express');

let route = express.Router();

const apiCtrl = require('../controllers/apiController.js');

//1.0 设定首页的ajax请求的路由规则
route.get('/api/getlist',apiCtrl.getlist);

//2.0 设定视频播放页面的ajax请求的路由规则
route.get('/api/getvideo',apiCtrl.getvideo);

module.exports = route;