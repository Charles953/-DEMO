'use strict'

const express = require('express');
let app = express();

//1.0 定一个与微信服务器进行交互的路由规则
app.all('/wxserver',(req,res)=>{

// 在我们的服务器中，只需要将echostr返回即可
// 这段代码在微信服务器公众平台后台管理中验证通过以后，就可以注释掉了
// let echostr = req.query.echostr;

// res.end(echostr);

//解析微信推送给我们的服务器的xml数据 （post请求）
  req.on('data',(requestBody)=>{

  	//1.0.1.1 将所有发送过来的xml数据转换成js对象
  	const parseString = require('xml2js').parseString;
	var xml = requestBody.toString();
	parseString(xml, function (err, result) {
		console.log(result);
		//1.0.1.2 再根据js对象中的相关的字段去判断到底是关注还是其他
	    if(result.xml.MsgType[0] =='event' && result.xml.Event[0] =='subscribe' )
	    {
	    	//关注事件
	    //2.0 利用被动回复消息中的文本消息xml格式，将欢迎消息响应到微信客户端
	    let resXml = `<xml>
					<ToUserName><![CDATA[${result.xml.FromUserName}]]></ToUserName>
					<FromUserName><![CDATA[${result.xml.ToUserName}]]></FromUserName>
					<CreateTime>12345678</CreateTime>
					<MsgType><![CDATA[text]]></MsgType>
					<Content><![CDATA[欢迎关注！！！]]></Content>
					</xml>
	    `;

	    res.end(resXml);
	    //console.log('进来了没有');
	    }


//2.0 对微信客户端和服务器端进行通讯的处理
if(result.xml.MsgType[0]=='text'){
	//TODO:定义一些关键字做不同的响应即可
	//这段xml代表的是响应一个纯文本回去
	 // let resXml = `<xml>
		// 			<ToUserName><![CDATA[${result.xml.FromUserName}]]></ToUserName>
		// 			<FromUserName><![CDATA[${result.xml.ToUserName}]]></FromUserName>
		// 			<CreateTime>12345678</CreateTime>
		// 			<MsgType><![CDATA[text]]></MsgType>
		// 			<Content><![CDATA[你好]]></Content>
		// 			</xml>
	 //    `;
	 //    
	 //    
	 //    
	 // 响应一个图文消息回去
	 let resXml = `
	 		<xml>
			<ToUserName><![CDATA[${result.xml.FromUserName}]]></ToUserName>
			<FromUserName><![CDATA[${result.xml.ToUserName}]]></FromUserName>
			<CreateTime>12345678</CreateTime>
			<MsgType><![CDATA[news]]></MsgType>
			<ArticleCount>1</ArticleCount>
			<Articles>
			<item>
			<Title><![CDATA[NODEjs]]></Title> 
			<Description><![CDATA[NodeJS项目微信开发]]></Description>
			<PicUrl><![CDATA[https://www.baidu.com/img/bd_logo1.png]]></PicUrl>
			<Url><![CDATA[http://github.com]]></Url>
			</item>
			</Articles>
			</xml>
	 `;
 	res.end(resXml);

}
});


  });
});


app.listen(8890,()=>{

	console.log('8890');
});

