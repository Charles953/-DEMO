/*
  
app.js的职责:仅仅是开启一个web服务器而已，
他不用关心如何去设置路由规则，以及如何去处理业务逻辑，如何去处理视图

	express开启网站服务器的步骤：
	1、安装express   npm i express --save
	2、导入express:  var express = require('express')
	3、实例化一个application
	4、设定路由规则
	5、监听端口

 */

'use strict'


//1.0 port变量的值是从环境变量中来的
let port = process.env.PORT || 8877;

const express = require('express');

const bodyParser = require('body-parser'); 
const ueditor = require("ueditor");
const path = require('path');

let app = express();

app.use(bodyParser());

const  session = require('express-session');
app.use(session({
  secret: 'cz03',  //加密的秘钥，可以随便写
  resave: false,
  saveUninitialized: true
  //cookie: { secure: true } // 表示当浏览器第一次请求这个网站的时候，就会向浏览器写一个身份标识到它的cookie中
}));


// 1.0 初始化orm的模型数据 （orm一定是本地安装）
//1.0.1 导包
const orm =require('orm');
global.orm= orm;
//app.use(orm.express('mysql的链接字符串',function(db对象,models,next){}));
app.use(orm.express('mysql://root:123456@127.0.0.1:3306/gzcz03',{
	define:function(db,models,next){

		//1.0.1.1 初始化模型
		models.userinfo = db.define('userinfo',{
			uid:{type:'serial',key:true},
			uname:String,
			upwd:String,
			ustatus:Number
		});


		models.videinfo = db.define('videinfo',{
			vid:{type:'serial',key:true},
			vtitle:String,
			vsortno:Number,
			vvideid:String,
			vsummary:String,
			vremark:String,
			vimg:String
		});
  
		next();
	}
}));

//2.0 将网站的statics这个文件夹当做系统的静态资源文件夹
let phyPath = __dirname + '/statics/';
app.use(express.static(phyPath));



//3.0 将admin这个区域下面的所有响应方法加入一个charset=utf-8的设置
app.all('*',(req,res,next)=>{
		res.setHeader("Content-Type","text/html;charset=utf-8");
		next(); //表示进入到admin下面的某个具体的路由规则中
});

//3.0.1 在admin这个区域下的所有路由规则中加入一个是否登录了的判断
//统一的登录判断
app.all('/admin/*',(req,res,next)=>{
	if(req.session.uname == null)
	{
		res.end('<script>alert("用户未登录");window.location="/account/login"</script>');
		return;
	}
	next();
});

// 3.0 设定路由规则
const accountRoute = require('./routes/accountRoute.js');
app.use('/',accountRoute);

const adminRoute = require('./routes/adminRoute.js');
app.use('/',adminRoute);


// 这种方式其实就是在express框架中加载使用bodyParser中间件
// app.use(bodyParser.urlencoded({
//   extended: true
// }))
// app.use(bodyParser.json());
// 

app.use("/ueditor/ue", ueditor(path.join(__dirname, 'statics'), function(req, res, next) {
  // ueditor 客户发起上传图片请求
  if(req.query.action === 'uploadimage'){
    var foo = req.ueditor;

    var imgname = req.ueditor.filename;

    var img_url = '/images/ueditor/';  //表示图片的保存路径
    res.ue_up(img_url); //你只要输入要保存的地址 。保存操作交给ueditor来做
  }
  //  客户端发起图片列表请求
  else if (req.query.action === 'listimage'){
    var dir_url = '/images/ueditor/';
    res.ue_list(dir_url);  // 客户端会列出 dir_url 目录下的所有图片
  }
  // 客户端发起其它请求
  else {

    res.setHeader('Content-Type', 'application/json');
    //重定向（跳转）
    res.redirect('/ueditor/nodejs/config.json');
}}));

app.listen(port,()=>{
	console.log('express 服务器启动'+port);
});

