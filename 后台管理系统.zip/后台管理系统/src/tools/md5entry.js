
'use strict'

const crypto = require('crypto');

const secret = 'cz03';

module.exports = function(str){
	return crypto.createHmac('md5', secret)
                   .update(str) // 要加密的明文
                   .digest('hex');  //将二进制数据转换为16进制数据 ,hex代表16进制
}
