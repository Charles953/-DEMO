'use strict'
//1.0 导入express包
const express = require('express');

//2.0 利用其中的Router方法产生一个路由对象
let route = express.Router();

//3.0 在路由对象上设定路由规则
//将controller/accountController.js导入
let accCtrl = require('../controller/accountController.js');
route.get('/test',accCtrl.test);

//登录的路由规则
route.get('/account/login',accCtrl.getlogin);  //获取登录页面的
route.post('/account/login',accCtrl.postlogin);//接收登录请求的
route.get('/account/vcode',accCtrl.getvcode); //获取验证码

route.get('/account/logout',accCtrl.logout);
//4.0 将路由对象暴露出去
module.exports = route;
