'use strict'

const express = require('express');

let adminRoute = express.Router();

const adminCtrl = require('../controller/adminController.js');

//设计路由规则
//1.0 列表
//1.0.1 有一条get的路由规则，来实现列表数据的获取
// 对应浏览器中的url：http://127.0.0.1:8877/admin/list
adminRoute.get('/admin/list',adminCtrl.getlist);


//2.0 新增
//的业务：
//1、先要向服务器发送一个get请求获取到新增页面
//2、将用户填写好的表单数据post提交给服务器，服务器在将数据插入到数据表videinfo中
//// 对应浏览器中的url：http://127.0.0.1:8877/admin/add
adminRoute.get('/admin/add',adminCtrl.getadd);
//对应浏览器中的url：http://127.0.0.1:8877/admin/add
adminRoute.post('/admin/add',adminCtrl.postadd);

//3.0 编辑
//对应浏览器中的url：http://127.0.0.1:8877/admin/edit/你要编辑数据的id值
adminRoute.get('/admin/edit/:vid',adminCtrl.getedit);

adminRoute.post('/admin/edit/:vid',adminCtrl.postedit);

//4.0 删除
////对应浏览器中的url：http://127.0.0.1:8877/admin/delete/你要删除数据的id值
adminRoute.get('/admin/delete/:vid',adminCtrl.getdelete);



module.exports = adminRoute;
