'use strict'

const path = require('path');
const xtpl = require('xtpl');  //安装xtpl 的时候一定是 npm i xtemplate xtpl --save
exports.test = (req,res)=>{
	res.setHeader('Content-Type','text/html;charset=utf-8');
	//在这里我想要查询出userinfo表的所有数据展示在浏览器中
	
	//1.0 查询表userinfo，得到一个数组 [{uid:1,uname:"admin",upwd:'123456',ustatus:0},{},{}]
	req.models.userinfo.find({},{},(err,datas)=>{

	console.log(datas);

	//2.0 利用 xtpl.renderFile()方法将数据渲染到模板页面上
	//renderFile()中的第一个路径是从 day01src目录启动的(因为当前的web服务器执行路径是day01src)
		xtpl.renderFile(path.join(__dirname,'../view/test.html'),{arr:datas},(err,html)=>{
		if(err)
		{
			res.end(err.message); //将错误消息的摘要响应到浏览器 (aa is not function)
			console.log(err); //详细的错误堆栈信息打应到cmd面板上
			return; //阻止下面代码的继续运行
		}

		//2.0.1 创建一个模板： 在view 文件夹中test.html模板
	//2.0.2 利用res.end()将最终生成好的html代码响应给浏览器
		res.end(html);
	});
		
	});
}


//登录
exports.getlogin=(req,res)=>{

	xtpl.renderFile(path.join(__dirname,'../view/login.html'),{},(err,html)=>{
		if(err)
		{
			res.end(err.message);
			return;
		}
		res.end(html);
	});
}

exports.postlogin=(req,res)=>{
	//1.0 获取浏览器发送过来的请求报文体中的数据
	let uname = req.body.uname;
	let upwd = req.body.upwd;  //明文密码

	upwd = require('../tools/md5entry.js')(upwd);
	console.log(upwd);

	let vcode = req.body.vcode;
	
	//2.0 获取服务器中属于这个浏览器的验证码字符串与浏览器提交过来的验证码比对
	let vodeFromSession = req.session.vcode;
	if(vodeFromSession != vcode)
	{
		res.end('<script>alert("验证码输入错误");</script>');
		return;
	}
	//3.0 验证用户名和密码的正确性
	req.models.userinfo.find({uname:uname,upwd:upwd},{},(err,datas)=>{
	if(err)
	{
		res.end('<script>alert("用户名和密码错误");</script>');
		return;
	}

	//4.0 将用户名存储到session中(这个uname的值如果为null代表没有登陆过，则应该跳转到登录页面)
	req.session.uname = uname;
	//4.0 跳转到 /admin/list
	res.end('<script>alert("登录成功");window.location="/admin/list"</script>');

	});
}

exports.getvcode=(req,res)=>{
	//1.0  产生一个验证码字符串
	let vcode = parseInt(Math.random()*9000+1000);
	//2.0 将验证码字符串保存到session中 (express-session)
	req.session.vcode = vcode;
	
	const captchapng = require('captchapng');

	//3.0 将验证码字符串变成一个图片响应回去 ()
	 var p = new captchapng(80,30,vcode); // width,height,numeric captcha
        p.color(0, 0, 0, 0);  // First color: background (red, green, blue, alpha)
        p.color(80, 80, 80, 255); // Second color: paint (red, green, blue, alpha)

        var img = p.getBase64();
        var imgbase64 = new Buffer(img,'base64');
        res.writeHead(200, {
            'Content-Type': 'image/png'
        });
        res.end(imgbase64);
}


exports.logout = (req,res)=>{
//1.0 将req.session.uname这个登录标识的值设置为null
req.session.uname = null;
//2.0 跳转到登录页面
res.end('<script>alert("退出成功");window.location="/account/login"</script>');
}
