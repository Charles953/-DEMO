'use strict'

const path = require('path');
const xtpl = require('xtpl');

//1.0 实现列表数据的获取和list.html的渲染工作
exports.getlist = (req, res) => {
	let searcheValue = req.query.searchValue;

	//1.0 获取到数据表videinfo中数据总条数
	req.models.videinfo.count({vtitle:global.orm.like('%'+searcheValue+'%')},(err,count)=>{

		if(err)
		{
			res.end(err.message);
			return;
		}
		//2.0 计算出总页数 产生一个数组 [1,2,3,....]
		let pages = [];
		for (var i = 1; i <= count; i++) {
			 pages.push(i);
		};

		//3.0 动态计算出跳过的总条数
		let pageIndex = parseInt(req.query.pageindex || 1); 
		let pageSize= parseInt(req.query.pagesize || 3);

		let skipCount = (pageIndex - 1 ) * pageSize;

		 //4.0 去数据库中查找videinfo这个表中的数据
    	req.models.videinfo.find({vtitle:global.orm.like('%'+searcheValue+'%')}, {offset:skipCount,limit:pageSize}, (err, datas) => {
        //2.0调用xtpl.renderFile()将要页面渲染
        var obj = { list: datas,loginedname:req.session.uname,pages:pages,searchValue:searcheValue };
        xtpl.renderFile(path.join(__dirname, '../view/list.html'), obj, (err, html) => {

            if (err) {
                res.end(err.message);
                return;
            }
            res.end(html);
        });
    });

	});
	
}


//-------- 新增开始
exports.getadd = (req, res) => {

    //1.0 直接将add.html渲染出去
    xtpl.renderFile(path.join(__dirname, '../view/add.html'), {}, (err, html) => {

        if (err) {
            res.end(err.message);
            return;
        }

        res.end(html);

    });
}


exports.postadd = (req, res) => {
    //1.0 通过req.body. 拿到请求报文体数据
    let vtitle = req.body.vtitle;
    let vsortno = req.body.vsortno;
    let vvideid = req.body.vvideid;
    let vsummary = req.body.vsummary;
    let vremark = req.body.editorValue;
    let vimg = req.body.vimg;

    //2.0 强数据插入到db的videinfo中
    let videData = {
        vtitle: vtitle,
        vsortno: vsortno,
        vvideid: vvideid,
        vsummary: vsummary,
        vremark: vremark,
        vimg: vimg
    };
    //req.models.videinfo.create(你要插入的数据js对象,回调函数);
    req.models.videinfo.create(videData, (err, item) => {
        if (err) {
            res.end(err.message);
            return;
        }
        //3.0 先提示新增成功，再跳转到 /admin/list中
        res.end('<script>alert("新增成功");window.location="/admin/list"</script>');
    });
}

//--------新增结束
//
//-------- 编辑开始
exports.getedit = (req, res) => {

    //0.0 从url中后去到vid的值
    let vid = req.params.vid;

    //1.0 根据vid的值从mysql数据库中查找视频数据
    req.models.videinfo.find({ vid: vid }, {}, (err, data) => {
        if (data.length <= 0) {
            res.end('id值非法，没有对应数据');
            return;
        }

        //console.log(data[0].vremark);
        //2.0 渲染edit.html页面
        xtpl.renderFile(path.join(__dirname, '../view/edit.html'), data[0], (err, html) => {
            res.end(html);
        });
    });
}


exports.postedit = (req, res) => {

    //0.0 获取更新数据的主键
    //不管是get还是post请求，均可以获取到
    let vid = req.params.vid;

    //1.0 利用orm查询出这条数据
    req.models.videinfo.get(vid, (err, data) => {
        //将页面上传入进来的所有数据一一赋值给data中的相对应的属性即可
        data.vtitle = req.body.vtitle;
        data.vsortno = req.body.vsortno;
        data.vvideid = req.body.vvideid;
        data.vsummary = req.body.vsummary;
        data.vremark = req.body.editorValue;
        data.vimg = req.body.vimg;

        //将修改以后的数据真正更新回db
        data.save((err)=>{
        	if(err)
        	{
        		res.end(err.message);
        		return;
        	}

        	res.end('<script>alert("数据更新成功");window.location="/admin/list";</script>');
        });
    })

}

//-------编辑结束
//
//
////--------删除开始
exports.getdelete = (req, res) => {
	//1.0 根据list.html中的js写法，确定将来响应回去的数据一定是json并且其格式是：
	//{"status":1,"message":"提示语"}

	let resObj = {status:0,message:"删除成功"};
	let success = 0;
	let fial = 1;

	//1.0 删除数据
	//get()方法返回是唯一的一条数据
	//find()返回的是一个数组
	req.models.videinfo.get(req.params.vid,(err,data)=>{
		if(err)
		{
			resObj.status = fial;
			resObj.message = err.message;

			res.end(JSON.stringify(resObj));
			
			return;
		}

		data.remove((err)=>{
		if(err)
		{
			resObj.status = fial;
			resObj.message = err.message;
			res.end(JSON.stringify(resObj));
			return;
		}

		//响应回异步对象
		res.end(JSON.stringify(resObj));
		})
	});
}


//--------删除结束
