'use strict'

const gulp = require('gulp');

gulp.task('default',['minjs','mincss','cssmd5','cssmd5replace'],function(){

	console.log('gulp任务完成');
});


//1.0 js压缩 
//注意点：gulp-uglify 是不认识es6语法结构的，所以我们还应该先将所有的代码全部转换成
//es5的语法,但是这个过程一定是要自动化的
// 所以：gulp中有一个插件： gulp-babel 可以自动将 es6语法转换成es5语法
const minjs = require('gulp-uglify');
const es6toes5 = require('gulp-babel');
gulp.task('minjs',()=>{

	gulp.src(['./src/controller/*.js','./src/routes/*.js'
		,'./src/tools/*.js','./src/statics/js/test.js'],{base:'src'})
	// gulp.src(['./src/test.js'],{base:'src'})
	.pipe(es6toes5({presets: ['es2015']})) //表示将 js文件由es6转换成es5
	.pipe(minjs()) //再来压缩就不会报错了
	.pipe(gulp.dest('dist'));

	console.log('js压缩完毕');
});

//2.0 css压缩
const mincss= require('gulp-clean-css');
gulp.task('mincss',()=>{
	gulp.src('./src/statics/css/*.css',{base:'src'})
	.pipe(mincss({compatibility: 'ie8'}))
	.pipe(gulp.dest('dist'));
	console.log('css压缩完毕');
});

//3.0 imge压缩
const imagemin = require('gulp-imagemin');
gulp.task('imagemin',()=>{
	gulp.src('./src/statics/image/*.*',{base:'src'})
    .pipe(imagemin())
    .pipe(gulp.dest('dist'))
});

//4.0 css文件的md5后缀(但是也可以扩展到js和image) ->统称为静态资源
const rev = require('gulp-rev');  
gulp.task('cssmd5',()=>{
	gulp.src('./src/statics/css/*.css',{base:'src'})
	.pipe(rev()) //通过rev() 将./src/statics/css/下面的所有的css文件名称加入一个md5的字符串后缀
	.pipe(gulp.dest('dist')) //将新的文件输出到dist中
	.pipe(rev.manifest()) //自动生成一个 manifest.json文件，这个文件中将原来的site.css文件和新文件 site-6a7deb0a7b.css建立key-value关系 例如：{ "statics/css/site.css": "statics/css/site-6a7deb0a7b.css"}
	.pipe(gulp.dest('./src/rev/')); //将manifest.json文件拷贝到./src/rev/下面
	console.log('css压缩完毕');
});

//5.0 将html文件中引用到的css文件的名称替换成md5以后的
const revCollector = require('gulp-rev-collector');  //替换静态资源文件名称插件
const htmlmin = require('gulp-htmlmin');

	gulp.task('cssmd5replace', function() {
	 	
	 	gulp.src(['./src/rev/**/*.json', './src/view/*.html'],{base:'src'})
	        .pipe(revCollector())  // 先替换./src/views/ 下面的所有html中的内容
	        .pipe(htmlmin({collapseWhitespace: true}))  // 压缩view下面的 所有的html ,collapseWhitespace:true:代表将html中的空格给去掉
	        .pipe(gulp.dest('dist'));
	});

//6.0 将需要拷贝的文件拷贝到dist中
gulp.task('copyfile',()=>{
	gulp.src(['./src/statics/images/**/*.*'
		,'./src/statics/node_modules/**/*.*'
		,'./src/statics/ueditor/**/*.*','./src/app.js'],{base:'src'})
	.pipe(gulp.dest('dist'));
});
