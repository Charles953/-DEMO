'use strict'

const express = require('express');
let app = express();


const orm = require('orm');
app.use(orm.express('mysql://root:123456@127.0.0.1:3306/gzcz03',{
	define:function(db,models,next){
  
		next();
	}
}));

app.all('/wxserver', (req, res) => {

	//data事件是接收微信服务器post这个服务器的数据
    req.on('data', (requestBody) => {

    //1.0.1.1 将所有发送过来的xml数据转换成js对象
    const parseString = require('xml2js').parseString;
    var xml = requestBody.toString();
    parseString(xml, function(err, result) {

    	//1.0 处理关注事件
    	if(result.xml.MsgType[0]=='event' && result.xml.Event[0]=='subscribe'){
    		let gzObj =  require('./processor/guanzhu.js');
    		gzObj.process(result,res);
    	}
    	
    	//2.0 处理搜索关键词的逻辑
    	if(result.xml.MsgType[0]=='text'){
    		let gzObj =  require('./processor/keywordSearch.js');
    		gzObj.process(result,req,res);
    	}
    });

});
});


app.listen(8890, () => {

    console.log('8890');
});
