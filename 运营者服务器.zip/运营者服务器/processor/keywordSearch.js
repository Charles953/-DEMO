'use strict'

exports.process=(result,req,res)=>{


	//1.0 获取到搜索的关键字
	let keyword = result.xml.Content[0];
	//2.0 去表中查询出数据
	let sql = "select vid,vtitle,vsummary,vimg from videinfo where vtitle like '%"+keyword+"%'";
	req.db.driver.execQuery(sql,(err,datas)=>{
		//3.0.1 获取到数据的总条数
		let rowCount = datas.length;

		let items ='';

		//3.0.3 datas生成一个个的item的xml格式
		for (var i = 0; i < rowCount; i++) {
			let row = datas[i];
			items+=`
				<item>
				<Title><![CDATA[${row.vtitle}]]></Title> 
				<Description><![CDATA[${row.vsummary}]]></Description>
				<PicUrl><![CDATA[${row.vimg}]]></PicUrl>
				<Url><![CDATA[http://cz03mui.ittun.com/VideoApp/play.html?vid=${row.vid}]]></Url>
				</item>
			`;
		};

		 let resXml = `
	 		<xml>
			<ToUserName><![CDATA[${result.xml.FromUserName}]]></ToUserName>
			<FromUserName><![CDATA[${result.xml.ToUserName}]]></FromUserName>
			<CreateTime>12345678</CreateTime>
			<MsgType><![CDATA[news]]></MsgType>
			<ArticleCount>${rowCount}</ArticleCount>
			<Articles>
			${items}
			</Articles>
			</xml>
	 `;
		//4.0 响应回去
		console.log(resXml);
		res.end(resXml);
	});
	

}