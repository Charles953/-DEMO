'use strict'
exports.process = (result,res)=>{

	 let resXml = `<xml>
				<ToUserName><![CDATA[${result.xml.FromUserName}]]></ToUserName>
				<FromUserName><![CDATA[${result.xml.ToUserName}]]></FromUserName>
				<CreateTime>12345678</CreateTime>
				<MsgType><![CDATA[text]]></MsgType>
				<Content><![CDATA[欢迎关注！！！\r\n 请点击链接查看所有视频：\r\n<a href="http://charles.ittun.com/VideoApp/index.html">查看视频列表</a> \r\n另外：你可以输入任何关键字去查询
相关视频]]></Content>
				</xml>
	    `;
	res.end(resXml);
}