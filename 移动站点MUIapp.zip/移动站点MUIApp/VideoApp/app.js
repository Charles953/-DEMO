'use strict'

const express=  require('express');

let app = express();

//1.0 将当前目录变成express的静态资源目录即可
app.use(express.static(__dirname));

app.listen(8878,()=>{
	console.log('video site started 8878');
});
